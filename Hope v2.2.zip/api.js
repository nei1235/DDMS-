const client = require('./connection.js')
const express = require('express');
const app = express();

app.listen(3300, ()=>{
    console.log("Sever is now listening at port 3300");
})

client.connect();

app.get('/doctors', (req, res)=>{
    client.query(`Select * from doctors`, (err, result)=>{
        if(!err){
            res.send(result.rows);
        }
    });
    client.end;
})

app.get('/admin', (req, res)=>{
    client.query(`Select * from admin`, (err, result)=>{
        if(!err){
            res.send(result.rows);
        }
    });
    client.end;
})

app.get('/patients', (req, res)=>{
    client.query(`Select * from patients`, (err, result)=>{
        if(!err){
            res.send(result.rows);
        }
    });
    client.end;
})

app.get('/users', (req, res)=>{
    client.query(`Select * from users`, (err, result)=>{
        if(!err){
            res.send(result.rows);
        }
    });
    client.end;
})

app.get('/medhistory', (req, res)=>{
    client.query(`Select * from medhistory`, (err, result)=>{
        if(!err){
            res.send(result.rows);
        }
    });
    client.end;
})

app.get('/users/:user_id', (req, res)=>{
    client.query(`Select * from users where user_id=${req.params.user_id}`, (err, result)=>{
        if(!err){
            res.send(result.rows);
        }
    });
    client.end;
})

app.get('/doctors/:doctor_id', (req, res)=>{
    client.query(`Select * from doctors where doctor_id=${req.params.doctor_id}`, (err, result)=>{
        if(!err){
            res.send(result.rows);
        }
    });
    client.end;
})

app.get('/patients/:patient_id', (req, res)=>{
    client.query(`Select * from patients where patient_id=${req.params.patient_id}`, (err, result)=>{
        if(!err){
            res.send(result.rows);
        }
    });
    client.end;
})

app.get('/admin/:admin_id', (req, res)=>{
    client.query(`Select * from admin where admin_id=${req.params.admin_id}`, (err, result)=>{
        if(!err){
            res.send(result.rows);
        }
    });
    client.end;
})

app.get('/medhistory/:mh_id', (req, res)=>{
    client.query(`Select * from medhistory where mh_id=${req.params.mh_id}`, (err, result)=>{
        if(!err){
            res.send(result.rows);
        }
    });
    client.end;
})

app.post('/users', (req, res)=> {
    const user = req.body;
    let insertQuery = `insert into users(user_id, full_name, address, city, gender, email, password, registration_date, update_date) 
                       values(${user.user_id}, '${user.full_name}', '${user.address}', '${user.city}', '${user.gender}', '${user.email}', '${user.password}', '${user.registration_date}', '${user.update_date})`

    client.query(insertQuery, (err, result)=>{
        if(!err){
            res.send('Insertion was successful')
        }
        else{ console.log(err.message) }
    })
    client.end;
})

app.post('/doctors', (req, res)=> {
    const doctor = req.body;
    let insertQuery = `insert into doctors(doctor_id, doctor_name, address, city, doc_fees, contact_no, doc_email, password, creation_date, updation_date) 
                       values(${doctor.doctor_id}, '${doctor.doctor_name}', '${doctor.address}', '${doctor.city}', '${doctor.doc_fees}', '${doctor.contact_no}', '${doctor.doc_email}', '${doctor.password}', '${doctor.creation_date}', '${doctor.updation_date})`

    client.query(insertQuery, (err, result)=>{
        if(!err){
            res.send('Insertion was successful')
        }
        else{ console.log(err.message) }
    })
    client.end;
})