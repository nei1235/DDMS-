import React, {useState, useEffect} from 'react';
function App() {
  const [patients, setPatients] = useState(false);
  useEffect(() => {
    getPatients();
  }, []);
  function getPatient() {
    fetch('http://localhost:3002')
      .then(response => {
        return response.text();
      })
      .then(data => {
        setPatients(data);
      });
  }
  function createPatient() {
    let patient_name = prompt('Enter patient name');
    let pemail = prompt('Enter patient email');
    fetch('http://localhost:3002/patients', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({patient_name, pemail}),
    })
      .then(response => {
        return response.text();
      })
      .then(data => {
        alert(data);
        getPatientnt();
      });
  }
  function deletePatient() {
    let patient_id = prompt('Enter patient id');
    fetch(`http://localhost:3002/patients/${patient_id}`, {
      method: 'DELETE',
    })
      .then(response => {
        return response.text();
      })
      .then(data => {
        alert(data);
        getPatient();
      });
  }
  return (
    <div>
      {patients ? patients : 'There is no patient data available'}
      <br />
      <button onClick={createPatient}>Add patient</button>
      <br />
      <button onClick={deletePatient}>Delete patient</button>
    </div>
  );
}
export default App;

